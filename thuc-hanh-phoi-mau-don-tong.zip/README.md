# Thực hành: Sử dụng màu sắc trong trang web

## Nội dung
- `index.html`: trang web hoàn chỉnh, responsive, có bộ lọc sản phẩm và giỏ hàng minh họa.
- Bảng màu đơn tông xanh dương lấy `#00ADEE` làm màu chủ đạo.
- Nền banner dùng `#00BFF2`, nhãn ON SALE/PREVIEW dùng `#00ADEE`, khu vực lợi ích dùng `#8DD7F7`, footer dùng `#C6E9FA`.
- Màu chữ chính dùng đen/xám đậm để dễ đọc.
- Phần cuối trang có bảng 10 sắc độ của bảng màu đơn tông.

## Cách chạy
Mở `index.html` bằng trình duyệt (Chrome, Edge, Firefox). Không cần cài đặt thư viện.

## Cách nộp
1. Tạo một repository GitHub mới.
2. Upload `index.html` và `README.md` (hoặc upload toàn bộ nội dung ZIP sau khi giải nén).
3. Nhấn **Commit changes**.
4. Sao chép đường dẫn repository và dán vào phần nộp bài.
5. Nếu muốn có đường dẫn xem trực tiếp: vào **Settings → Pages**, chọn nhánh `main` và thư mục `/ (root)`, lưu lại. Sau khi GitHub Pages được triển khai, nộp đường dẫn trang web được tạo.

## Ghi chú
Đây là bản thực hành độc lập theo yêu cầu phối màu đơn tông, được dựng lại thành trang mẫu hoàn chỉnh để có thể chạy ngay.
